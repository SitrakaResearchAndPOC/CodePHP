<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculatrice en PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        label, select, input {
            display: block;
            width: 100%;
            margin: 10px 0;
        }
        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .result {
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Calculatrice en PHP</h1>
        <form method="post" action="">
            <label for="number1">Nombre 1 :</label>
            <input type="number" id="number1" name="number1" step="any" required>
            
            <label for="number2">Nombre 2 :</label>
            <input type="number" id="number2" name="number2" step="any" required>
            
            <label for="operation">Opération :</label>
            <select id="operation" name="operation" required>
                <option value="addition">Addition</option>
                <option value="soustraction">Soustraction</option>
                <option value="multiplication">Multiplication</option>
                <option value="division">Division</option>
            </select>
            
            <button type="submit" name="calculate">Calculer</button>
        </form>
        
        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['calculate'])) {
                $num1 = $_POST['number1'];
                $num2 = $_POST['number2'];
                $operation = $_POST['operation'];
                $result = '';

                if (is_float(floatval($num1)) && is_float(floatval($num2))) {
                    switch ($operation) {
                        case 'addition':
                            $result = $num1 + $num2;
                            break;
                        case 'soustraction':
                            $result = $num1 - $num2;
                            break;
                        case 'multiplication':
                            $result = $num1 * $num2;
                            break;
                        case 'division':
                            if ($num2 == 0) {
                                $result = "Erreur : Division par zéro impossible.";
                            } else {
                                $result = $num1 / $num2;
                            }
                            break;
                        default:
                            $result = "Opération non valide.";
                            break;
                    }
                    echo "Résultat : $result";
                } else {
                    echo "Veuillez entrer des nombres valides.";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>

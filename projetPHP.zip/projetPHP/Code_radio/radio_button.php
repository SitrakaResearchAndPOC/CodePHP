<?php
// Définir une valeur par défaut (par exemple, depuis un formulaire ou une base de données)
$selectedOption = isset($_POST['gender']) ? $_POST['gender'] : '';

// Vérifier quelle option doit être sélectionnée
function isChecked($value, $selectedOption) {
    return $value === $selectedOption ? 'checked' : '';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bouton Radio en PHP</title>
</head>
<body>
    <form method="post" action="">
        <label>
            <input type="radio" name="gender" value="homme" <?= isChecked('homme', $selectedOption); ?>>
            Homme
        </label>
        <label>
            <input type="radio" name="gender" value="femme" <?= isChecked('femme', $selectedOption); ?>>
            Femme
        </label>
        <label>
            <input type="radio" name="gender" value="autre" <?= isChecked('autre', $selectedOption); ?>>
            Autre
        </label>
        <button type="submit">Envoyer</button>
    </form>

    <?php
    // Afficher la valeur sélectionnée après la soumission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo "<p>Vous avez sélectionné : <strong>" . htmlspecialchars($selectedOption) . "</strong></p>";
    }
    ?>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer la valeur de l'option sélectionnée
    $selectedOption = isset($_POST['option']) ? $_POST['option'] : null;

    // Vérifier et afficher la valeur
    if ($selectedOption) {
        echo "<h1>Vous avez sélectionné : " . htmlspecialchars($selectedOption) . "</h1>";
    } else {
        echo "<h1>Erreur : aucune option n'a été sélectionnée.</h1>";
    }
} else {
    // Rediriger si l'utilisateur accède à cette page sans soumettre le formulaire
   // header('Location: formulaire.php');
    exit;
}
?>

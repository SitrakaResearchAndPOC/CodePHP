<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire avec Boutons Radio</title>
</head>
<body>
    <h1>Choisissez une option</h1>
   
    <form method="post" action="">
        <label>
            <input type="radio" name="option" value="Option 1">
            Option 1
        </label>
        <br>
        <label>
            <input type="radio" name="option" value="Option 2">
            Option 2
        </label>
        <br>
        <label>
            <input type="radio" name="option" value="Option 3">
            Option 3
        </label>
        <br><br>
        <button type="submit">Envoyer</button>
    </form>

	<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer la valeur de l'option sélectionnée
    $selectedOption = isset($_POST['option']) ? $_POST['option'] : null;

    // Vérifier et afficher la valeur
    if ($selectedOption) {
        echo "<h1>Vous avez sélectionné : " . htmlspecialchars($selectedOption) . "</h1>";
    } else {
        echo "<h1>Erreur : aucune option n'a été sélectionnée.</h1>";
    }
} else {
    // Rediriger si l'utilisateur accède à cette page sans soumettre le formulaire
    // header('Location: index.php');
    exit;
}
?>

	
</body>
</html>

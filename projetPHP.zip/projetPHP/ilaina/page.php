<?php
    echo "salut tous le monde";
?>
<?php
 // J'ai choisi le mot de passe "kangourou"
 if (isset($_POST['mot_de_passe'])) // Si la variable existe
 {
    // On se crée une variable $mot_de_passe avec le mot de passe entré
    $mot_de_passe = $_POST['mot_de_passe'];
 }
 else // La variable n'existe pas encore
 {
    $mot_de_passe = ""; // On crée une variable $mot_de_passe vide
 }
 if ($mot_de_passe == "kangourou") // Si le mot de passe est bon
 {
 // On affiche la page cachée.
 ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
    <head>
        <title>Codes d'accès au serveur central de la NASA</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
        <h2>Voici les codes d'accès :</h2>
        <h3>CRD6-GTFT-CK65-JOPM-V29N-24G1-HH28-LLFV</h3>
        
        <hr />
        
        <p>
        Cette page est réservée au personnel de la NASA. N'oubliez pas de la visiter
 régulièrement car les codes d'accès sont changés toutes les semaines.<br />
        La NASA vous remercie de votre visite.
        </p>
    </body>
 </html>
 <?php
 }
 else // le mot de passe n'est pas bon
 {
 // On affiche la zone de texte pour rentrer le mot de passe.
 ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
    <head>
        <title>Page protégée par mot de passe</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
 <p>Veuillez entrer le mot de passe pour obtenir les codes d'accès au serveur central de
 la NASA :</p>
 <form action="protection.php" method="post">
 <p>
 <input type="password" name="mot_de_passe" /> <input type="submit" value="Valider" />
 </p>
 </form>
 <p>Cette page est réservée au personnel de la NASA. Si vous ne travaillez pas à la NASA,
 inutile d'insister vous ne trouverez jamais le mot de passe ! ;-)</p>
    </body>
 </html>
 <?php
 } // Fin du else
 // Fin du code :)
 ?>

<?php
 // La fonction array permet de créer un array
 $prenoms = ["François", "Marie", "Michel", "Nicole", "Véronique", "Benoît"];
 // Puis on fait une boucle pour tout afficher :
 for ($numero = 0; $numero < count($prenoms); $numero++)
 {
    echo $prenoms[$numero]; // affichera $prenoms[0], $prenoms[1] etc...
    echo "<br />"; // pour aller à la ligne
 }
 ?>

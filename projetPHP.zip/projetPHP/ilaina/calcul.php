<?php
function Afficher_nombre($i, $nombre){
    $i = $i+1;
    echo "Mon affichage n° ". $i . "est ". $nombre . "<br/>";   
    return $i;
}
 $i = 0;

 $nombre = 2 + 4; // $nombre prend la valeur 6
 $i = Afficher_nombre($i, $nombre);

 $nombre = 5 - 1; // $nombre prend la valeur 4
 $i = Afficher_nombre($i, $nombre);

 $nombre = 3 * 5; // $nombre prend la valeur 15
 $i = Afficher_nombre($i, $nombre);

 $nombre = 10 / 2; // $nombre prend la valeur 5
 // Allez on rajoute un peu de difficulté
 $i = Afficher_nombre($i, $nombre);

 $nombre = 3 * 5 + 1; // $nombre prend la valeur 16
 $i = Afficher_nombre($i, $nombre);

 $nombre = (1 + 2) * 2; // $nombre prend la valeur 6
 $i = Afficher_nombre($i, $nombre);

?>
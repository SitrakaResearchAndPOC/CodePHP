<p>
Veuillez taper votre mot de passe :
</p>
<form action="cible.php" method="post">
    <p>
       <input type="password" name="prenom" /> <input type="submit" value="Valider" />
    </p>
</form>

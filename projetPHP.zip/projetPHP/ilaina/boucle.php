<?php
/*
    $nb = 1;
    while ($nb <= 100){
        echo "$nb) je suis ici <br/>";
        $nb++;
    }
*/
    for($nb=1;$nb<=100;$nb++){
        echo "$nb) je suis ici <br/>";
    }
?>
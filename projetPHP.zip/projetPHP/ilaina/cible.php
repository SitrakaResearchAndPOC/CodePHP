<p>Bonjour !</p>
<p>Je sais comment tu t'appelles, hé hé. Tu t'appelles <?php echo $_POST['prenom']; ?> !</p>
 
<p>Si tu veux changer de prénom, <a href="appel.php">clique ici</a> pour revenir à
 appel.php
</p>

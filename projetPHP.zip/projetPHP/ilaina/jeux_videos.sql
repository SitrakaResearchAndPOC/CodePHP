-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 20 nov. 2024 à 13:15
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `coursphp`
--

-- --------------------------------------------------------

--
-- Structure de la table `jeux_videos`
--

CREATE TABLE `jeux_videos` (
  `id` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `possesseur` varchar(200) NOT NULL,
  `Console` varchar(25) NOT NULL,
  `prix` int(11) NOT NULL,
  `nbre_joueurs_max` int(11) NOT NULL,
  `commentaires` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `jeux_videos`
--

INSERT INTO `jeux_videos` (`id`, `nom`, `possesseur`, `Console`, `prix`, `nbre_joueurs_max`, `commentaires`) VALUES
(1, 'Super Mario Bros', 'Florent', 'NES', 4, 1, 'Un jeu d\'anthologie !'),
(2, 'Sonic', 'Patrick', 'Megadrive', 2, 1, 'Pour moi, le meilleur jeu au monde !'),
(3, 'Zelda : ocarina of time', 'Florent', 'Nitendo64', 15, 1, 'Un jeu grand, beau et complet comme on en \r\nvoit rarement de nos jours'),
(4, 'Mario Kart 64', 'Florent', 'Nitendo64', 25, 4, 'Un excellent jeu de kart !'),
(5, 'Super Smash Bros Melee', 'Michel', 'GameCube', 55, 4, 'Un jeu de baston délirant !');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `jeux_videos`
--
ALTER TABLE `jeux_videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `jeux_videos`
--
ALTER TABLE `jeux_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
    <head>
        <title>Bienvenue sur mon site !</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
        <p>

        Bienvenue sur mon site web !<br />
            <?php 
                $nbre_visiteurs = 10;
                echo("Vous êtes le visiteur n° " . $nbre_visiteurs); 
            ?>
        <br />
        Cliquez <a href="http://www.siteduzero.com">ici</a> pour entrer !
        </p>
    </body>
 </html>
<?php

$age = 12;
 if ($age <= 12)
 {
 echo "Salut gamin !";
 }else{
 echo "salut mon grand !";
 }
 
 ?>

<?php
// mysql_connect("localhost", "root", ""); // Connexion à MySQL
// mysql_select_db("coursphp"); // Sélection de la base coursphp

$host = "127.0.0.1";
$username = "root";
$pass = "";
$databasename = "coursphp";

$con = mysqli_connect($host, $username, $pass, $databasename);

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
/*
// Perform query
if ($result = mysqli_query($con, "SELECT * FROM jeux_videos")) {
  echo "Returned rows are: " . mysqli_num_rows($result);
  // Free result set
  mysqli_free_result($result);
}
*/


// $reponse = mysql_query("SELECT * FROM jeux_videos"); // Requête SQL
 // On fait une boucle pour lister tout ce que contient la table :


$sql = "SELECT * FROM jeux_videos";
$result = $con->query($sql);
// Numeric array
//$row = mysqli_fetch_array($result, MYSQLI_NUM);
//printf ("%s (%s)\n", $row[0], $row[1]);
?>
<table>
    <tr>
        <th>Nom</th>
        <th>Possesseur</th>
        <th>Console</th>
        <th>Prix</th>
        <th>Nbre_joueurs_max</th>
        <th>Commentaires </th>

    </tr>
<?php
while ($donnees = mysqli_fetch_array($result))
{
 ?>
 <!-- ici c'est du html -->
  <tr>
    <td> <?php echo $donnees['nom']; ?> </td>
    <td> <?php echo $donnees['possesseur']; ?> </td>
    <td> <?php echo $donnees['console']; ?> </td>
    <td> <?php echo $donnees['prix']; ?> </td>
    <td> <?php echo $donnees['nbre_joueurs_max']; ?> </td>
    <td> <?php echo $donnees['commentaires']; ?> </td>
</tr>


<?php
 }
 
// mysql_close(); // Déconnexion de MySQL
mysqli_close($con);
 ?>
</table>
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['agree']) && $_POST['agree'] === "yes") {
        echo "<h1>Merci d'avoir accepté les termes et conditions !</h1>";
    } else {
        echo "<h1>Vous n'avez pas accepté les termes et conditions.</h1>";
    }
} else {
    echo "<h1>Aucune donnée reçue</h1>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire avec Checkbox</title>
</head>
<body>
    <h1>Formulaire avec Cases à Cocher</h1>
    <form action="check_traitement.php" method="post">
        <p>Sélectionnez vos préférences :</p>
        
        <input type="checkbox" id="option1" name="options[]" value="Option 1">
        <label for="option1">Option 1</label><br>
        
        <input type="checkbox" id="option2" name="options[]" value="Option 2">
        <label for="option2">Option 2</label><br>
        
        <input type="checkbox" id="option3" name="options[]" value="Option 3">
        <label for="option3">Option 3</label><br>
        
        <button type="submit">Envoyer</button>
    </form>
</body>
</html>
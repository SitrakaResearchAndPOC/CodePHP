<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['options']) && is_array($_POST['options'])) {
        $options = $_POST['options'];

        echo "<h1>Options sélectionnées</h1>";
        echo "<ul>";
        foreach ($options as $option) {
            echo "<li>" . htmlspecialchars($option) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<h1>Aucune option sélectionnée</h1>";
    }
} else {
    echo "<h1>Aucune donnée reçue</h1>";
}
?>

<?php
$host = "127.0.0.1";
$username = "root";
$pass = "";
$databasename = "coursphp";

$con = mysqli_connect($host, $username, $pass, $databasename);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Initialisation des variables pour la pagination
$limit = 1; // Nombre de jeux par page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        // Créer un nouveau jeu
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];
        
        $sql_insert = "INSERT INTO jeux_videos (nom, possesseur, prix, console, nbre_joueurs_max, commentaires) 
                       VALUES ('$nom', '$possesseur', '$prix', '$console', '$nbre_joueurs_max', '$commentaires')";
        mysqli_query($con, $sql_insert);
    }

    if (isset($_POST['delete'])) {
        // Supprimer un jeu
        $id = $_POST['id'];
        $sql_delete = "DELETE FROM jeux_videos WHERE id = $id";
        mysqli_query($con, $sql_delete);
    }

    if (isset($_POST['update'])) {
        // Mettre à jour un jeu
        $id = $_POST['id'];
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];
        
        $sql_update = "UPDATE jeux_videos SET nom='$nom', possesseur='$possesseur', prix='$prix', 
                       console='$console', nbre_joueurs_max='$nbre_joueurs_max', commentaires='$commentaires' WHERE id=$id";
        mysqli_query($con, $sql_update);
    }
}

// Affichage des jeux avec pagination
$sql_count = "SELECT COUNT(*) FROM jeux_videos";
$result_count = mysqli_query($con, $sql_count);
$total_rows = mysqli_fetch_array($result_count)[0];
$total_pages = ceil($total_rows / $limit);

$sql_select = "SELECT * FROM jeux_videos LIMIT $limit OFFSET $offset";
$result_select = mysqli_query($con, $sql_select);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Jeux Vidéo</title>
</head>
<body>
    <h1>Gestion des Jeux Vidéo</h1>

    <!-- Formulaire d'affichage des jeux -->
    <h2>Affichage des Jeux Vidéo</h2>
    <?php while ($donnees = mysqli_fetch_array($result_select)) { ?>
        <p>
            <strong>Jeu :</strong> <?php echo $donnees['nom']; ?><br />
            <strong>Possesseur :</strong> <?php echo $donnees['possesseur']; ?><br />
            <strong>Prix :</strong> <?php echo $donnees['prix']; ?> euros<br />
            <strong>Console :</strong> <?php echo $donnees['console']; ?><br />
            <strong>Joueurs maximum :</strong> <?php echo $donnees['nbre_joueurs_max']; ?><br />
            <strong>Commentaires :</strong> <?php echo $donnees['commentaires']; ?><br />
        </p>
    <?php } ?>

    <!-- Pagination -->
    <div>
        <a href="?page=<?php echo $page - 1; ?>" <?php if ($page <= 1) echo 'style="visibility:hidden"'; ?>>Précédent</a> |
        <a href="?page=<?php echo $page + 1; ?>" <?php if ($page >= $total_pages) echo 'style="visibility:hidden"'; ?>>Suivant</a>
    </div>

    <hr />

    <!-- Formulaire pour créer un jeu -->
    <h2>Ajouter un Nouveau Jeu</h2>
    <form method="post" action="">
        <label for="nom">Nom :</label>
        <input type="text" name="nom" required><br>
        <label for="possesseur">Possesseur :</label>
        <input type="text" name="possesseur" required><br>
        <label for="prix">Prix :</label>
        <input type="number" name="prix" required><br>
        <label for="console">Console :</label>
        <input type="text" name="console" required><br>
        <label for="nbre_joueurs_max">Joueurs Max :</label>
        <input type="number" name="nbre_joueurs_max" required><br>
        <label for="commentaires">Commentaires :</label>
        <textarea name="commentaires" required></textarea><br>
        <button type="submit" name="create">Créer</button>
    </form>

    <hr />

    <!-- Formulaire pour supprimer un jeu -->
    <h2>Supprimer un Jeu</h2>
    <form method="post" action="">
        <label for="id">ID du Jeu :</label>
        <input type="number" name="id" required><br>
        <button type="submit" name="delete">Supprimer</button>
    </form>

    <hr />

    <!-- Formulaire pour modifier un jeu -->
    <h2>Modifier un Jeu</h2>
    <form method="post" action="">
        <label for="id">ID du Jeu :</label>
        <input type="number" name="id" required><br>
        <label for="nom">Nom :</label>
        <input type="text" name="nom" required><br>
        <label for="possesseur">Possesseur :</label>
        <input type="text" name="possesseur" required><br>
        <label for="prix">Prix :</label>
        <input type="number" name="prix" required><br>
        <label for="console">Console :</label>
        <input type="text" name="console" required><br>
        <label for="nbre_joueurs_max">Joueurs Max :</label>
        <input type="number" name="nbre_joueurs_max" required><br>
        <label for="commentaires">Commentaires :</label>
        <textarea name="commentaires" required></textarea><br>
        <button type="submit" name="update">Modifier</button>
    </form>

    <hr />

</body>
</html>

<?php
// Fermer la connexion à la base de données
mysqli_close($con);
?>

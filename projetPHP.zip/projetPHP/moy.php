<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcul de la Moyenne</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h3 {
            text-align: center;
        }
        table {
            width: 100%;
            margin: 10px 0;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            text-align: left;
            padding: 8px;
        }
        input[type="number"] {
            width: 100%;
            padding: 5px;
        }
        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .result {
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Calcul de la Moyenne et Mention</h3>
        <form method="post" action="">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>
            <br/>
            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" required>

            <table>
                <tr>
                    <th>Matière</th>
                    <th>Note (/20)</th>
                </tr>
                <tr>
                    <td>Mathématiques</td>
                    <td><input type="number" name="maths" min="0" max="20" step="0.1" required></td>
                </tr>
                <tr>
                    <td>Anglais</td>
                    <td><input type="number" name="anglais" min="0" max="20" step="0.1" required></td>
                </tr>
                <tr>
                    <td>Français</td>
                    <td><input type="number" name="francais" min="0" max="20" step="0.1" required></td>
                </tr>
                <tr>
                    <td>Connaissance Générale</td>
                    <td><input type="number" name="cg" min="0" max="20" step="0.1" required></td>
                </tr>
                <tr>
                    <td>Informatique</td>
                    <td><input type="number" name="info" min="0" max="20" step="0.1" required></td>
                </tr>
            </table>

            <button type="submit" name="submit">Calculer</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
                $nom = htmlspecialchars(trim($_POST['nom']));
                $prenom = htmlspecialchars(trim($_POST['prenom']));
                $maths = floatval($_POST['maths']);
                $anglais = floatval($_POST['anglais']);
                $francais = floatval($_POST['francais']);
                $cg = floatval($_POST['cg']);
                $info = floatval($_POST['info']);

                // Calcul de la moyenne
                $moyenne = ($maths + $anglais + $francais + $cg + $info) / 5;

                // Détermination de la mention
                if ($moyenne >= 16) {
                    $mention = "Excellent";
                } elseif ($moyenne >= 14) {
                    $mention = "Bien";
                } elseif ($moyenne >= 12) {
                    $mention = "Assez Bien";
                } elseif ($moyenne >= 10) {
                    $mention = "Passable";
                } else {
                    $mention = "Insuffisant";
                }

                // Affichage des résultats
                echo "Étudiant : " . htmlspecialchars($prenom) . " " . htmlspecialchars($nom) . "<br>";
                echo "Moyenne : " . number_format($moyenne, 2) . "<br>";
                echo "Mention : " . $mention;
            }
            ?>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire avec Deux Boutons</title>
</head>
<body>
    <h1>Formulaire avec Deux Actions</h1>
    
    <?php
    // Vérifier si un formulaire a été soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['action'])) {
            if ($_POST['action'] == 'affichage') {
                echo "<p><strong>Action choisie : Affichage</strong></p>";
            } elseif ($_POST['action'] == 'modification') {
                echo "<p><strong>Action choisie : Modification</strong></p>";
            }
        }
    } else {
        echo "<p>Veuillez choisir une action :</p>";
    }
    ?>

    <!-- Formulaire avec deux boutons -->
    <form method="post" action="">
        <button type="submit" name="action" value="affichage">Affichage</button>
        <button type="submit" name="action" value="modification">Modification</button>
    </form>
</body>
</html>

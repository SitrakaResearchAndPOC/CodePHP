<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération du pays sélectionné
    $pays = isset($_POST['pays']) ? $_POST['pays'] : null;

    // Vérification et affichage
    if ($pays) {
        echo "<h1>Vous avez sélectionné : " . htmlspecialchars($pays) . "</h1>";
    } else {
        echo "<h1>Aucun pays sélectionné.</h1>";
    }
} else {
    echo "<h1>Erreur : le formulaire n'a pas été soumis correctement.</h1>";
}

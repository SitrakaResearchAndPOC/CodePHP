<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choix du Pays</title>
</head>
<body>
    <form method="post" action="traitement.php">
        <p>
            <label for="pays">Dans quel pays habitez-vous ?</label><br />
            <select name="pays" id="pays">
                <option value="france">France</option>
                <option value="espagne">Espagne</option>
                <option value="italie">Italie</option>
                <option value="royaume-uni">Royaume-Uni</option>
                <option value="canada">Canada</option>
                <option value="etats-unis">États-Unis</option>
                <option value="chine">Chine</option>
                <option value="japon">Japon</option>
            </select>
        </p>
        <button type="submit">Envoyer</button>
    </form>
</body>
</html>

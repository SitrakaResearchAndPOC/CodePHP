<?php
// Initialisation de la variable pour le pays sélectionné
$selectedCountry = null;

// Vérification si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedCountry = isset($_POST['pays']) ? $_POST['pays'] : null;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choix du Pays</title>
</head>
<body>
    <h1>Formulaire : Choisissez votre pays</h1>
    
    <form method="post" action="">
        <p>
            <label for="pays">Dans quel pays habitez-vous ?</label><br />
            <select name="pays" id="pays">
                <option value="france" <?= $selectedCountry === 'france' ? 'selected' : ''; ?>>France</option>
                <option value="espagne" <?= $selectedCountry === 'espagne' ? 'selected' : ''; ?>>Espagne</option>
                <option value="italie" <?= $selectedCountry === 'italie' ? 'selected' : ''; ?>>Italie</option>
                <option value="royaume-uni" <?= $selectedCountry === 'royaume-uni' ? 'selected' : ''; ?>>Royaume-Uni</option>
                <option value="canada" <?= $selectedCountry === 'canada' ? 'selected' : ''; ?>>Canada</option>
                <option value="etats-unis" <?= $selectedCountry === 'etats-unis' ? 'selected' : ''; ?>>États-Unis</option>
                <option value="chine" <?= $selectedCountry === 'chine' ? 'selected' : ''; ?>>Chine</option>
                <option value="japon" <?= $selectedCountry === 'japon' ? 'selected' : ''; ?>>Japon</option>
            </select>
        </p>
        <button type="submit">Envoyer</button>
    </form>

    <?php
    // Affichage du résultat après soumission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($selectedCountry) {
            echo "<h2>Vous avez sélectionné : <strong>" . htmlspecialchars($selectedCountry) . "</strong></h2>";
        } else {
            echo "<h2>Aucun pays sélectionné.</h2>";
        }
    }
    ?>
</body>
</html>

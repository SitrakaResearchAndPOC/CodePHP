<?php
$host = "127.0.0.1";
$username = "root";
$pass = "";
$databasename = "coursphp";

$con = mysqli_connect($host, $username, $pass, $databasename);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Initialisation des variables pour la pagination
$limit = 1; // Nombre de jeux par page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Actions
$action = isset($_POST['action']) ? $_POST['action'] : 'display'; // Par défaut l'action est l'affichage

$jeu = []; // Initialisation de la variable jeu pour afficher les données dans le formulaire

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action == 'create') {
        // Créer un nouveau jeu
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];
        
        $sql_insert = "INSERT INTO jeux_videos (nom, possesseur, prix, console, nbre_joueurs_max, commentaires) 
                       VALUES ('$nom', '$possesseur', '$prix', '$console', '$nbre_joueurs_max', '$commentaires')";
        mysqli_query($con, $sql_insert);
    }

    if ($action == 'delete') {
        // Supprimer un jeu
        $id = $_POST['id'];
        $sql_delete = "DELETE FROM jeux_videos WHERE id = $id";
        mysqli_query($con, $sql_delete);
    }

    if ($action == 'update') {
        // Mettre à jour un jeu
        $id = $_POST['id'];
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];
        
        $sql_update = "UPDATE jeux_videos SET nom='$nom', possesseur='$possesseur', prix='$prix', 
                       console='$console', nbre_joueurs_max='$nbre_joueurs_max', commentaires='$commentaires' WHERE id=$id";
        mysqli_query($con, $sql_update);
    }
}

// Affichage des jeux avec pagination uniquement lorsque l'action est "display"
if ($action == 'display') {
    // Requête pour compter le nombre total de jeux
    $sql_count = "SELECT COUNT(*) FROM jeux_videos";
    $result_count = mysqli_query($con, $sql_count);
    $total_rows = mysqli_fetch_array($result_count)[0];
    $total_pages = ceil($total_rows / $limit);

    // Requête pour récupérer les jeux avec pagination
    $sql_select = "SELECT * FROM jeux_videos LIMIT $limit OFFSET $offset";
    $result_select = mysqli_query($con, $sql_select);
    
    // Si un jeu est sélectionné, insérer ses données dans le formulaire
    if ($donnees = mysqli_fetch_array($result_select)) {
        $jeu = $donnees;
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Jeux Vidéo</title>
</head>
<body>
    <h1>Gestion des Jeux Vidéo</h1>

    <!-- Formulaire Unique pour toutes les actions -->
    <h2>
        <?php 
        // Affichage du titre en fonction de l'action choisie
        switch ($action) {
            case 'create':
                echo 'Ajouter un Nouveau Jeu';
                break;
            case 'update':
                echo 'Modifier un Jeu';
                break;
            case 'delete':
                echo 'Supprimer un Jeu';
                break;
            default:
                echo 'Affichage des Jeux Vidéo';
                break;
        }
        ?>
    </h2>

    <form method="post" action="">
        <!-- Champs communs pour toutes les actions -->
        <label for="nom">Nom :</label>
        <input type="text" name="nom" value="<?php echo isset($jeu['nom']) ? $jeu['nom'] : ''; ?>" required><br>

        <label for="possesseur">Possesseur :</label>
        <input type="text" name="possesseur" value="<?php echo isset($jeu['possesseur']) ? $jeu['possesseur'] : ''; ?>" required><br>

        <label for="prix">Prix :</label>
        <input type="number" name="prix" value="<?php echo isset($jeu['prix']) ? $jeu['prix'] : ''; ?>" required><br>

        <label for="console">Console :</label>
        <input type="text" name="console" value="<?php echo isset($jeu['console']) ? $jeu['console'] : ''; ?>" required><br>

        <label for="nbre_joueurs_max">Joueurs Max :</label>
        <input type="number" name="nbre_joueurs_max" value="<?php echo isset($jeu['nbre_joueurs_max']) ? $jeu['nbre_joueurs_max'] : ''; ?>" required><br>

        <label for="commentaires">Commentaires :</label>
        <textarea name="commentaires" required><?php echo isset($jeu['commentaires']) ? $jeu['commentaires'] : ''; ?></textarea><br>

        <!-- ID du jeu (pour modification et suppression) -->
        <?php if ($action == 'update' || $action == 'delete') { ?>
            <label for="id">ID du Jeu :</label>
            <input type="number" name="id" value="<?php echo isset($jeu['id']) ? $jeu['id'] : ''; ?>" required><br>
        <?php } ?>

        <!-- Affichage ou action selon l'action -->
        <div>
            <?php 
            if ($action == 'display') { 
                // Pas besoin d'afficher les jeux ici, car les informations sont dans les inputs
            }
            ?>
        </div>

        <!-- Boutons pour l'action -->
        <button type="submit" name="action" value="create">Ajouter</button>
        <button type="submit" name="action" value="update">Modifier</button>
        <button type="submit" name="action" value="delete">Supprimer</button>
        <button type="submit" name="action" value="display">Afficher</button>
    </form>

    <!-- Pagination -->
    <div>
        <?php if ($action == 'display') { ?>
            <a href="?page=<?php echo $page - 1; ?>" <?php if ($page <= 1) echo 'style="visibility:hidden"'; ?>>Précédent</a> |
            <a href="?page=<?php echo $page + 1; ?>" <?php if ($page >= $total_pages) echo 'style="visibility:hidden"'; ?>>Suivant</a>
        <?php } ?>
    </div>

</body>
</html>

<?php
// Fermer la connexion à la base de données
mysqli_close($con);
?>

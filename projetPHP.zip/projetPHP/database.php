<?php
// mysql_connect("localhost", "root", ""); // Connexion à MySQL
// mysql_select_db("coursphp"); // Sélection de la base coursphp

$host = "127.0.0.1";
$username = "root";
$pass = "";
$databasename = "coursphp";

$con = mysqli_connect($host, $username, $pass, $databasename);

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
/*
// Perform query
if ($result = mysqli_query($con, "SELECT * FROM jeux_videos")) {
  echo "Returned rows are: " . mysqli_num_rows($result);
  // Free result set
  mysqli_free_result($result);
}
*/


// $reponse = mysql_query("SELECT * FROM jeux_videos"); // Requête SQL
 // On fait une boucle pour lister tout ce que contient la table :


$sql = "SELECT * FROM jeux_videos";
$result = $con->query($sql);
// Numeric array
//$row = mysqli_fetch_array($result, MYSQLI_NUM);
//printf ("%s (%s)\n", $row[0], $row[1]);

while ($donnees = mysqli_fetch_array($result))
{
 ?>
 <p>
 <strong>Jeu</strong> : <?php echo $donnees['nom']; ?><br />
 Le possesseur de ce jeu est : <?php echo $donnees['possesseur']; ?>, et il le vend à
 <?php echo $donnees['prix']; ?> euros !<br />
 Ce jeu fonctionne sur <?php echo $donnees['console']; ?> et on peut y jouer à <?php echo
 $donnees['nbre_joueurs_max']; ?> au maximum<br />
 <?php echo $donnees['possesseur']; ?> a laissé ces commentaires sur <?php echo
 $donnees['nom']; ?> : <em><?php echo $donnees['commentaires']; ?></em>
 </p>
 <?php
 }
 
// mysql_close(); // Déconnexion de MySQL
	mysqli_close($con);



	?>
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);

    echo "<h1>Informations Reçues</h1>";
    echo "<p>Nom : $nom</p>";
    echo "<p>Prénom : $prenom</p>";
} else {
    echo "<h1>Aucune donnée reçue</h1>";
}
?>

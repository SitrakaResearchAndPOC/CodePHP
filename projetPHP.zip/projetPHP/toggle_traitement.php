<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['toggle']) && $_POST['toggle'] === "on") {
        echo "<h1>Le Toggle Button est activé.</h1>";
    } else {
        echo "<h1>Le Toggle Button est désactivé.</h1>";
    }
} else {
    echo "<h1>Aucune donnée reçue.</h1>";
}
?>
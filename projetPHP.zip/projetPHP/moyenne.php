<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcul de la Moyenne</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        label, input {
            display: block;
            width: 100%;
            margin: 10px 0;
        }
        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .result {
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Calcul de la Moyenne et Mention</h1>
        <form method="post" action="">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>

            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" required>

            <label for="maths">Note de Mathématiques :</label>
            <input type="number" id="maths" name="maths" min="0" max="20" step="0.1" required>

            <label for="anglais">Note d'Anglais :</label>
            <input type="number" id="anglais" name="anglais" min="0" max="20" step="0.1" required>

            <label for="francais">Note de Français :</label>
            <input type="number" id="francais" name="francais" min="0" max="20" step="0.1" required>

            <label for="cg">Note de Connaissance Générale :</label>
            <input type="number" id="cg" name="cg" min="0" max="20" step="0.1" required>

            <label for="info">Note d'Informatique :</label>
            <input type="number" id="info" name="info" min="0" max="20" step="0.1" required>

            <button type="submit" name="submit">Calculer</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
                $nom = htmlspecialchars(trim($_POST['nom']));
                $prenom = htmlspecialchars(trim($_POST['prenom']));
                $maths = floatval($_POST['maths']);
                $anglais = floatval($_POST['anglais']);
                $francais = floatval($_POST['francais']);
                $cg = floatval($_POST['cg']);
                $info = floatval($_POST['info']);

                // Calcul de la moyenne
                $moyenne = ($maths + $anglais + $francais + $cg + $info) / 5;

                // Détermination de la mention
                if ($moyenne >= 16) {
                    $mention = "Excellent";
                } elseif ($moyenne >= 14) {
                    $mention = "Bien";
                } elseif ($moyenne >= 12) {
                    $mention = "Assez Bien";
                } elseif ($moyenne >= 10) {
                    $mention = "Passable";
                } else {
                    $mention = "Insuffisant";
                }

                // Affichage des résultats
                echo "Étudiant : " . htmlspecialchars($prenom) . " " . htmlspecialchars($nom) . "<br>";
                echo "Moyenne : " . number_format($moyenne, 2) . "<br>";
                echo "Mention : " . $mention;
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
$host = "127.0.0.1";
$username = "root";
$pass = "";
$databasename = "coursphp";

$con = mysqli_connect($host, $username, $pass, $databasename);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Initialisation des variables pour afficher un jeu
$jeu = null;

// Actions selon le bouton cliqué
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['read'])) {
        // Lire un jeu par ID
        $id = $_POST['id'];
        $sql_select = "SELECT * FROM jeux_videos WHERE id = $id";
        $result = mysqli_query($con, $sql_select);
        $jeu = mysqli_fetch_array($result);
    }

    if (isset($_POST['create'])) {
        // Créer un nouveau jeu
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];

        $sql_insert = "INSERT INTO jeux_videos (nom, possesseur, prix, console, nbre_joueurs_max, commentaires) 
                       VALUES ('$nom', '$possesseur', '$prix', '$console', '$nbre_joueurs_max', '$commentaires')";
        mysqli_query($con, $sql_insert);
    }

    if (isset($_POST['update'])) {
        // Mettre à jour un jeu
        $id = $_POST['id'];
        $nom = $_POST['nom'];
        $possesseur = $_POST['possesseur'];
        $prix = $_POST['prix'];
        $console = $_POST['console'];
        $nbre_joueurs_max = $_POST['nbre_joueurs_max'];
        $commentaires = $_POST['commentaires'];

        $sql_update = "UPDATE jeux_videos SET nom='$nom', possesseur='$possesseur', prix='$prix', 
                       console='$console', nbre_joueurs_max='$nbre_joueurs_max', commentaires='$commentaires' WHERE id=$id";
        mysqli_query($con, $sql_update);
    }

    if (isset($_POST['delete'])) {
        // Supprimer un jeu
        $id = $_POST['id'];
        $sql_delete = "DELETE FROM jeux_videos WHERE id = $id";
        mysqli_query($con, $sql_delete);
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Jeux Vidéo</title>
</head>
<body>
    <h1>Gestion des Jeux Vidéo</h1>

    <!-- Formulaire principal pour toutes les actions -->
    <form method="post" action="">
        <label for="id">ID du Jeu :</label>
        <input type="number" name="id" value="<?php echo $jeu['id'] ?? ''; ?>" required><br>

        <label for="nom">Nom :</label>
        <input type="text" name="nom" value="<?php echo $jeu['nom'] ?? ''; ?>"><br>

        <label for="possesseur">Possesseur :</label>
        <input type="text" name="possesseur" value="<?php echo $jeu['possesseur'] ?? ''; ?>"><br>

        <label for="prix">Prix :</label>
        <input type="number" name="prix" value="<?php echo $jeu['prix'] ?? ''; ?>"><br>

        <label for="console">Console :</label>
        <input type="text" name="console" value="<?php echo $jeu['console'] ?? ''; ?>"><br>

        <label for="nbre_joueurs_max">Joueurs Max :</label>
        <input type="number" name="nbre_joueurs_max" value="<?php echo $jeu['nbre_joueurs_max'] ?? ''; ?>"><br>

        <label for="commentaires">Commentaires :</label>
        <textarea name="commentaires"><?php echo $jeu['commentaires'] ?? ''; ?></textarea><br>

        <button type="submit" name="read">Afficher</button>
        <button type="submit" name="create">Créer</button>
        <button type="submit" name="update">Modifier</button>
        <button type="submit" name="delete">Supprimer</button>
    </form>

</body>
</html>

<?php
// Fermer la connexion à la base de données
mysqli_close($con);
?>

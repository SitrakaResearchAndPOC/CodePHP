<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire avec une Case à Cocher</title>
</head>
<body>
    <h1>Formulaire avec une Case à Cocher</h1>
    <form action="agreement_traitement.php" method="post">
        <input type="checkbox" id="agree" name="agree" value="yes">
        <label for="agree">J'accepte les termes et conditions</label><br><br>
        
        <button type="submit">Envoyer</button>
    </form>
</body>
</html>
